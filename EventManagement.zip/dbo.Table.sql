﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [username] VARCHAR(50) NULL, 
    [password ] VARCHAR(50) NULL
)
