﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class PrivateParty : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["amountpage4"] = TextBox6.Text;
            SqlConnection con=new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into PrivateParty values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"','"+ DropDownList1.SelectedItem.Text+ "','"+TextBox5.Text+"','"+TextBox6.Text+"')",con);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Submitted Successfully'); </script>");
            con.Close();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Music.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedValue== "Private Meeting")
            {
                TextBox6.Text = "10000";
            }
            if (DropDownList1.SelectedValue == "Bachelor Party")
            {
                TextBox6.Text = "25000";
            }
            if (DropDownList1.SelectedValue == "Success Meet")
            {
                TextBox6.Text = "25000";
            }
            if (DropDownList1.SelectedValue == "VIP Events")
            {
                TextBox6.Text = "50000";
            }
          

        }
    }
}