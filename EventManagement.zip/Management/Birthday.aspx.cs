﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           if(!IsPostBack)
            {
                TextBox6.Text = "25000";
                TextBox7.Text = "Birthday";
            }
        }        
        
      

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["amountpage1"] = TextBox6.Text;
            SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Birthday values('" + TextBox1.Text + "','" + TextBox7.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "', '"+TextBox6.Text+"')", con);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Registered Successfully'); </script>");
            
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox5.Text = string.Empty;
            TextBox6.Text = string.Empty;

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Music.aspx");
        }
    }
}