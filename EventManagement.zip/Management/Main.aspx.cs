﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Management
{
    public partial class Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void Button1_Click(object sender, EventArgs e)
        {


            SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");

            SqlDataAdapter sda = new SqlDataAdapter("select * from Register where Name='" + TextBox1.Text + "' and pass='" + TextBox2.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                string name = TextBox1.Text;
                Session["username"] = name;
                Response.Redirect("Website.aspx");
                
            }
            else
            {
                Label4.Visible = true;
                Label4.ForeColor = System.Drawing.Color.Red;
                Label4.Text = "Incorrect Password or Username";
            }




        }

    }

}
