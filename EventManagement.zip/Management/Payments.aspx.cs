﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class Payments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                decimal total = 0;

                if (Session["amountpage1"] != null)
                    total += decimal.Parse(Session["amountpage1"].ToString());

                if (Session["amountpage2"] != null)
                    total += decimal.Parse(Session["amountpage2"].ToString());

                if (Session["amountpage3"] != null)
                    total += decimal.Parse(Session["amountpage3"].ToString());

                if (Session["amountpage4"] != null)
                    total += decimal.Parse(Session["amountpage4"].ToString());

                if (Session["amountpage5"] != null)
                    total += decimal.Parse(Session["amountpage5"].ToString());

                if (Session["amountpage6"] != null)
                    total += decimal.Parse(Session["amountpage6"].ToString());

                
                TextBox5.Text = total.ToString();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string valuetopass = TextBox5.Text;
            Session["ValueToPass"] = valuetopass;

            Response.Redirect("QrGen.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            string valuetopass = TextBox5.Text;
            Session["ValueToPass"] = valuetopass;

            Response.Redirect("QrGen.aspx");
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            string valuetopass = TextBox5.Text;
            Session["ValueToPass"] = valuetopass;

            Response.Redirect("QrGen.aspx");
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Card values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')", con);
            cmd.ExecuteNonQuery();

            con.Close();

            Label2.Visible = true;

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("Website.aspx");
        }
    }
}