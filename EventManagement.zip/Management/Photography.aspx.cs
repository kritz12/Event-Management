﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class Photography : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Foods.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "Baby Shower")
            {
                TextBox5.Text = "10000";
            }
            if (DropDownList1.SelectedValue == "Pre-Wedding Shoots")
            {
                TextBox5.Text = "12000";
            }
            if (DropDownList1.SelectedValue == "Post-Wedding Shoots")
            {
                TextBox5.Text = "12500";
            }
            if (DropDownList1.SelectedValue == "Birthday")
            {
                TextBox5.Text = "15000";
            }
            if (DropDownList1.SelectedValue == "House Warming")
            {
                TextBox5.Text = "14000";
            }
            if (DropDownList1.SelectedValue == "Engagement")
            {
                TextBox5.Text = "20000";
            }
            if (DropDownList1.SelectedValue == "Mehendi")
            {
                TextBox5.Text = "8000";
            }
            if (DropDownList1.SelectedValue == "Sangeeth")
            {
                TextBox5.Text = "9000";
            }
            if (DropDownList1.SelectedValue == "Haldi")
            {
                TextBox5.Text = "11000";
            }
            if (DropDownList1.SelectedValue == "Reception")
            {
                TextBox5.Text = "25000";
            }
            if (DropDownList1.SelectedValue == "Wedding")
            {
                TextBox5.Text = "30000";
            }
            if (DropDownList1.SelectedValue == "Others")
            {
                TextBox5.Text = "5000";
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["amountpage6"] =TextBox5.Text;
            SqlConnection con=new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Photoshoot values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"','"+DropDownList1.SelectedItem.Text+"','"+TextBox5.Text+"')",con);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Submitted Successfully'); </script>");
            con.Close();
        }
    }
}