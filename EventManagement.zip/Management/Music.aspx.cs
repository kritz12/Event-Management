﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class Music : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["amountpage3"] = TextBox2.Text;
            Response.Redirect("Photography.aspx");

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {


        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "DJ Music")
            {
                TextBox2.Text = "10000";
            }
            else if (DropDownList1.SelectedValue == "Traditional Music")
            {
                TextBox2.Text = "8000";
            }
            else if (DropDownList1.SelectedValue == "Rock Band")
            {
                TextBox2.Text = "9000";
            }
            else if (DropDownList1.SelectedValue == "Classical")
            {
                TextBox2.Text = "8500";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Photography.aspx");
        }
    }

}