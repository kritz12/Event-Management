﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class WebForm2 : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Website.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            string h3Value = h3Tag.InnerText;
            string pValue = pTag.InnerText;

            Response.Redirect("Fitems.aspx?h3Value=" + Server.UrlEncode(h3Value) + "&pValue=" + Server.UrlEncode(pValue));

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string h3Value = h3Tag1.InnerText;
            string pValue = pTag1.InnerText;

            Response.Redirect("Fitems.aspx?h3Value=" + Server.UrlEncode(h3Value) + "&pValue=" + Server.UrlEncode(pValue));



        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            string h3Value = h3Tag2.InnerText;
            string pValue = pTag2.InnerText;

            Response.Redirect("Fitems.aspx?h3Value=" + Server.UrlEncode(h3Value) + "&pValue=" + Server.UrlEncode(pValue));
        }


        protected void Button5_Click(object sender, EventArgs e)
        {
            string h3Value = h3Tag3.InnerText;
            string pValue = pTag3.InnerText;

            Response.Redirect("Fitems.aspx?h3Value=" + Server.UrlEncode(h3Value) + "&pValue=" + Server.UrlEncode(pValue));

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            string h3Value = h3Tag4.InnerText;
            string pValue = pTag4.InnerText;

            Response.Redirect("Fitems.aspx?h3Value=" + Server.UrlEncode(h3Value) + "&pValue=" + Server.UrlEncode(pValue));

        }
    }
}