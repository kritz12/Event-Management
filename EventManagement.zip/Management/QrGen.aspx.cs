﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.IO;
using System.Drawing;
using QRCoder;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class QrGen : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["ValueToPass"]!=null && !string.IsNullOrEmpty(Session["ValueToPass"].ToString()))
            {
                string valueFromPage1 = Session["ValueToPass"].ToString();
                txtAmount.Text = valueFromPage1;
            }
            
        }
        protected void btnGenerateQRCode_Click(object sender, EventArgs e)
        {
            
            string amount = txtAmount.Text;
            string vpa = "krithikappu12@ybl";
            string name = "KRITHIK"; 
            string currencyCode = "INR"; 

            string upiUrl = $"upi://pay?pa={vpa}&pn={name}&am={amount}&cu={currencyCode}";

            // Generate the QR code using QRCoder
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(upiUrl, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);

            // Convert the QR code to a bitmap image
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            // Display the QR code on the web page
            using (MemoryStream ms = new MemoryStream())
            {
                qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                byte[] imageBytes = ms.ToArray();
                imgQRCode.ImageUrl = "data:image/png;base64," + Convert.ToBase64String(imageBytes);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Label2.Visible = true;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Website.aspx");
        }
    }
}