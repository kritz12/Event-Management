﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class Fitems : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string h3Value = Request.QueryString["h3Value"];
                string pValue = Request.QueryString["pValue"];

                TextBox1.Text = h3Value;
                TextBox2.Text = pValue;

            }
            
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["amountpage5"] = TextBox4.Text;

            Response.Redirect("Payments.aspx");
        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}