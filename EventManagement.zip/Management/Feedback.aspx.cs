﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class ContactUS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void resetButton_Click(object sender, EventArgs e)
        {
            nameInput.Text = string.Empty;
            mail.Text = string.Empty;
            message.Text = string.Empty;
        }

        protected void submitButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Feedback values('" + nameInput + "','" + mail + "','" + message + "')", con);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('FeedBack Sent'); </script>");
            con.Close();

        }
    }
}