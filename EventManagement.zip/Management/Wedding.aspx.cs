﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Management
{
    public partial class Wedding : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["amountpage2"] = TextBox5.Text;

            SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Wedding values('" +TextBox1.Text + "','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"','"+DropDownList1.SelectedItem.Text+"','"+TextBox5.Text+"')",con);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert('Submitted Successfully'); </script>");
            con.Close();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedValue == "Engagement")
            {
                TextBox5.Text = "100000";
            }
            else if(DropDownList1.SelectedValue=="Mehendi")
            {
                TextBox5.Text = "80000";
            }
            else if(DropDownList1.SelectedValue=="Sangeeth")
            {
                TextBox5.Text = "90000";
            }
            else if(DropDownList1.SelectedValue=="Haldi")
            {
                TextBox5.Text = "95000";
            }
            else if(DropDownList1.SelectedValue=="Reception")
            {
                TextBox5.Text = "150000";
            }
            else if(DropDownList1.SelectedValue=="Wedding")
            {
                TextBox5.Text = "200000";
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Music.aspx");
        }
    }
}