﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Management
{
    public partial class Register : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {


        }
        public void Button1_Click(Object sender, EventArgs e)
        {
            if (ValidateFields())
             
            {
                SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB; Initial Catalog=Event; Integrated security=SSPI");
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Register values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')", con);
                cmd.ExecuteNonQuery();
                Response.Write("<script> alert('Registered Successfully'); </script>");

                con.Close();
            }
            

        }
        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(TextBox1.Text) ||
        string.IsNullOrWhiteSpace(TextBox2.Text) ||
        string.IsNullOrWhiteSpace(TextBox3.Text) ||
        string.IsNullOrWhiteSpace(TextBox4.Text) ||
        string.IsNullOrWhiteSpace(TextBox5.Text))
            {
                Response.Write("<script> alert('Please fill in all the fields.'); </script>");
                return false;
            }

            return true;
        }
        protected void Button2_Click(object sender, EventArgs e)
        {

            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            TextBox5.Text = string.Empty;

        }
    }
}